CREATE FUNCTION earth () RETURNS double precision
	LANGUAGE sql
AS $$
SELECT '6378168'::float8
$$
